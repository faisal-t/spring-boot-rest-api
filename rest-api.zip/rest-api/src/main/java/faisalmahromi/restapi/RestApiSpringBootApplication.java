package faisalmahromi.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiSpringBootApplication.class, args);
	}

}
